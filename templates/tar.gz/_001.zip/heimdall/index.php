<?php
	/**
	 * 获取主题设置参数
	 */
	//获取要显示的默认分类数据
	$default_category_id = intval($theme_config->default_category_id);
	//如果$default_category_id为0，说明用户没有设置默认要显示的分类，则取第一个权重最高的来显示
	if( empty($default_category_id) ) {
		$default_category_id = intval( $categorys[0]['id'] );
	}

	//获取CID（分类ID）参数
	$cid = @intval($_GET['cid']);
	//如果CID为空，或者小于等于0，则使用默认ID
	if( empty($cid) || $cid <= 0 ) {
		$cid = $default_category_id;
	}

	//获取图标显示方式
	$link_icon = $theme_config->link_icon;
	// var_dump($theme_config);
	//遍历所有分类，判断用户传递的分类是否是私有
	foreach ($categorys as $value) {
		if( $value['id'] == $cid ) {
			//如果是私有
			if( intval( $value['property'] ) === 1 ) {
				//判断是否登录
				if( is_login() ) {
					//用户已登录，获取分类下的所有链接，会自动判断私有权限
					$links = get_links($cid);
				}
				else{
					//私有分类，且没有登录
					$links = [];
				}
			}
			else{
				//该分类不是私有，查找分类下的链接
				$links = get_links($cid);
			}
			//终止循环
			break;
		}
	}

	//获取默认搜索引擎
	$default_search = $theme_config->default_search;
	
	//检查默认搜索引擎是否存在
	if( array_key_exists($default_search,$search_engines) ) {
		//如果存在
		$tmp_search[$default_search] = $search_engines[$default_search];
		//删除指定的搜索引擎
		unset($search_engines[$default_search]);
		
		//追加默认搜索引擎到第一位，使用array_merge合并
		$search_engines = array_merge($tmp_search,$search_engines);
		//array_unshift($search_engines,$tmp_search[$default_search]);
	}
	
?>
<!doctype html>
<html lang="zh">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title><?php echo $site['title']; ?> - <?php echo $site['subtitle']; ?></title>
		<meta name="keywords" content="<?php echo $site['keywords']; ?>" />
		<meta name="description" content="<?php echo $site['description']; ?>" />
		<link rel="mask-icon" href="templates/<?php echo $template; ?>/img/heimdall-logo-small.svg" color="black">
		<meta name="msapplication-TileColor" content="#ffffff">
		<meta name="theme-color" content="#ffffff">
		<meta name="mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<link rel="stylesheet" href="templates/<?php echo $template; ?>/css/app.css?v=<?php echo $version; ?>" type="text/css" />
		<link rel="stylesheet" href="templates/<?php echo $template; ?>/css/all.min.css" type="text/css" />
		<script src="templates/<?php echo $template; ?>/js/fontawesome.js"></script>
		<!-- 自定义Header部分 -->
		<?php echo $site['custom_header']; ?>
		<!-- 自定义Header END -->
	</head>
	<body>
		<div id="app">
			<div class="content">
				<main id="main">

					<!-- 搜索框 -->
					<div class="searchform">
						<div id="search-container" class="input-container">
							<select name="provider" id="engine">
								<!-- <option value="baidu" selected="selected">Baidu</option> -->
								<?php foreach ($search_engines as $key => $search) {
									if( $key === 0 ) {
										$key = "360";
									}
								?>
								<option value="<?php echo $key; ?>"><?php echo $search['name'] ?></option>
								<?php } ?>
							</select>
							<input class="homesearch" onkeydown="trigger_search();" placeholder="请输入关键词..." id = "q" name="q" type="text">
							<button type="submit" onclick="start_search()">搜索</button>
						</div>
					</div>
					<!-- 搜索框END -->

					<div id="sortable">

						<!-- 遍历默认分类下的链接 -->
						<?php foreach ($links as $link) {
							//根据用户的设置显示链接图标显示方式
							if( $link_icon == "custom" ) {
								$font_icon_url = $link['font_icon'];

								//如果用户选择了自定义图标，但是却没有设置图标，则用默认图标
								if( empty($font_icon_url) ) {
									$font_icon_url = 'static/images/default.png';
								}
							}
							else{
								$font_icon_url = "./index.php?c=ico&text=".$link['title'];
							}

							//如果描述为空，则设置一个默认描述
							if( empty($link['description']) ) {
								$link['description'] = "管理员未设置描述！";
							}

							//判断是否是直连模式
							if( $site['link_model'] === 'direct' ) {
								$url = $link['url'];
							}
							else{
								$url = './index.php?c=click&id='.$link['id'];
							}
						
						?>
						<!-- 单个链接 -->
						<div class="mylink">
						<section class="item-container">
							<div class="item" style="background-color: #161b1f">
								<!-- 链接图标 -->
								<div class="app-icon-container">
									<img class="app-icon" src="<?php echo $font_icon_url; ?>" />
								</div>
								<!-- 链接图标END -->
								
								<!-- 链接标题 -->
								<div class="details link-title">
									<div class="title white"><?php echo $link['title']; ?></div>
								</div>
								<!-- 链接标题END -->

								<!-- 隐藏链接，搜索使用 -->
								<div style = "display:none;">
									<?php echo $link['url']; ?>
								</div>
								<!-- 隐藏链接END -->

								<a rel="noopener noreferrer" onclick="this.blur();" class="link white" target="heimdall" href="<?php echo $url; ?>">
									<i class="fas fa-arrow-alt-to-right"></i>
								</a>
							</div>

							<!-- 编辑链接 -->
							<a class="item-edit" title = "编辑此链接" target = "_blank" href="./index.php?c=admin&page=edit_link&id=<?php echo $link['id']; ?>">
								<i class="fas fa-pencil"></i>
							</a>
							<!-- 编辑链接END -->

							<!-- 链接描述 -->
							<div class="tooltip">
								<?php echo $link['description']; ?>
							</div>
							<!-- 链接描述END -->
						</section>
						</div>
						<!-- 单个链接END -->
						<?php } ?>
						<!-- 遍历默认分类下的链接END -->
						
					</div>



					<div id="config-buttons" style = "z-index:9999;">
						<a id="items" class="config" href="javascript:;" title = "查看其它分类">
							<i class="fas fa-list"></i>
							<div class="tooltip left" style = "margin-bottom:66px;">
								<!-- 遍历所有分类 -->
								<?php foreach ($categorys as $category) {
									
								?>
								<div class="cat-name" title = "点击打开<?php echo $category['name']; ?>" onclick = "jump_category(<?php echo $category['id']; ?>)">
									<?php echo $category['name']; ?>
								</div>
								<?php } ?>
								<!-- 遍历所有分类END -->
							</div>
						</a>
						<?php 
							if( is_login() ) {
						?>
						<a id="config-button" class="config" href="javascript:;">
							<i class="fas fa-exchange"></i>
							<div class="tooltip left">切换编辑模式</div>
						</a>
						<a id="users" class="config" href="./index.php?c=admin">
							<i class="fas fa-user"></i>
							<div class="tooltip left">后台管理</div>
						</a>
						<?php }else{ ?>
							<!-- 没有登录的按钮 -->
							<a id="users" class="config" href="./index.php?c=login">
								<i class="fas fa-user"></i>
								<div class="tooltip left">登录</div>
							</a>
							<!-- 没有登录的按钮END -->
						<?php } ?>
					</div>
				</main>

			</div>
		</div>
		<!-- 页面底部 -->
		<div class="footer">
			<footer>
			<?php if(empty( $site['custom_footer']) ){ ?>
			© 2022 Powered by <a target = "_blank" href="https://github.com/helloxz/onenav" title = "简约导航/书签管理器" rel = "nofollow">OneNav</a>.The author is <a href="https://www.xiaoz.me/" target="_blank" title = "小z博客">xiaoz.me</a>
			<?php }else{
				echo $site['custom_footer'];
			} ?>
			</footer>
		</div>
		<!-- 页面底部END -->
		<script src="templates/<?php echo $template; ?>/js/jquery-3.6.0.min.js"></script>
		<script src="templates/<?php echo $template; ?>/js/jquery-ui.min.js"></script>
		<script src="templates/<?php echo $template; ?>/js/app_2.js"></script>
		<script src="static/js/holmes.js"></script>
		<script src="templates/<?php echo $template; ?>/js/embed.js?v=<?php echo $version; ?>"></script>
		<script id="custom_js">
			/* editable using the 'Settings > Advanced > Custom JavaScript' option */
		</script>
	</body>
</html>