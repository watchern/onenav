<!DOCTYPE html>
<html lang="">
  
  <head>
    <meta charset="utf-8">
    <meta content="<?php echo $site['keywords']; ?>" name="keywords">
    <meta content="<?php echo $site['description']; ?>" name="description">
    <meta content="IE=edge" http-equiv="X-UA-Compatible">
    <meta content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no" name="viewport">
    <meta content="width=device-width,initial-scale=1" name="viewport">
    <title>
      <?php echo $site[ 'title']; ?>-
        <?php echo $site[ 'subtitle']; ?></title>
    <script defer="defer" src="/templates/tushan/js/chunk-vendors.080dfe2c.js">
    </script>
    <script defer="defer" src="/templates/tushan/js/app.e5725e7c.js">
    </script>
    <link href="/templates/tushan/css/chunk-vendors.37bab8c1.css" rel="stylesheet">
    <link href="/templates/tushan/css/app.8196d6fd.css" rel="stylesheet">
    <?php echo $site['custom_header']; ?>
  </head>
  
  <body onselectstart="return false">
    <div id="app">
    </div>
  </body>

</html>