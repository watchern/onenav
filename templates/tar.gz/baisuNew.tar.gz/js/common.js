function CurrentTime() {
	var time = dayjs().format('HH:mm:ss');
	$('#time').text(time);
	var date = dayjs().format('YYYY 年 MM 月 DD 日');
	$('#date').text(date);
	setTimeout("CurrentTime()", 1000);
}

function CurrentDate() {
	var nowDate = new Date();
	var lunarD = Lunar.fromDate(nowDate);
	console.log(lunarD);
	var lunarNowDate = lunarD.getYearInGanZhi() + '年' + lunarD.getMonthInChinese() + "月" + lunarD.getDayInChinese();
	$('#nowLunar').text(lunarNowDate);
	var nowWeek = lunarD.getWeekInChinese();
	$('#nowWeek').text('星期' + nowWeek);
}
CurrentTime();
CurrentDate();

$(".siteList ").click(function() {
	var openurl = $(this).data('url');
	open_links(openurl);
});

$("a.typeList").click(function() {
	$("html, body").animate({
		scrollTop: $($(this).attr("href")).offset().top - 20 + "px"
	}, 500);
});

//二级菜单
$(".type-list .list").click(function() {
	console.log('222');
	$(this).addClass("hover").siblings().removeClass('hover');
	$(this).find('.list-sub').slideDown();
	$(this).siblings().find('.list-sub').slideUp();
});

//搜索
$('#seaech-to').click(function() {
	var kw = $('#search').val();
	var baidu = 'https://www.baidu.com/s?ie=UTF-8&wd=';
	window.open(baidu + kw);
	$(".site-tit").removeClass("hidden");
	$(".siteList").removeClass("hidden");
});

//回车键、本地搜索
function keyClick() {
	$('body').keyup(function(e) {
		if(e.keyCode === 13) {
			var isFocus = $("#search").is(":focus");
			if(true == isFocus) {
				console.log(isFocus);
				var kw = $('#search').val();
				var baidu = 'https://www.baidu.com/s?ie=UTF-8&wd=';
				window.open(baidu + kw);
				$(".site-tit").removeClass("hidden");
				$(".siteList").removeClass("hidden");
			}
		}
	});

	$("#search").blur(function(data, status) {
		if($("#search").val() == '') {
			$(".site-tit").removeClass("hidden");
		};
	});

	$("#search").bind("input propertychange", function(event) {
		if($("#search").val() == '') {
			$(".site-tit").removeClass("hidden");
		};
	});
	$("#search").focus(function(data, status) {
		$('.search-lists').addClass('hide');
	});
	var h = holmes({
		input: '#search',
		find: '.siteList',
		placeholder: '<div class="empty">未搜索到匹配结果！</div>',
		mark: false,
		hiddenAttr: true,
		class: {
			visible: 'visible',
				hidden: 'hidden'
		},
		onFound(el) {
			$(".site-tit").addClass("hidden");
		},
		onInput(el) {
			$(".site-tit").addClass("hidden");
		},
		onVisible(el) {
			$(".site-tit").removeClass("hidden");
		},
		onEmpty(el) {
			$(".site-tit").removeClass("hidden");
		},
	});

}
keyClick();


//打开书签
function open_links(url) {
	console.log(url)
	window.open(url);
}

//手机端
$('.wap-menu').click(function() {
	$(".navlist-main").toggle();
});

function close_window(){
	window.open('','_self');window.close();
}


$(document).ready(function() {
    const apiUrl = 'https://api-hot.efefee.cn/weibo?cache=true';

    $.getJSON(apiUrl, function(data) {
        const items = data.data.slice(0, 10); // 取前10条数据
        let count = 1;
        items.forEach(function(item) {
            const link = $('<a>', { href: item.url, target: '_blank',title: item.title }).text(item.title);
            const listItem = $('<div>').addClass('item').html('<span class="item-number">' + count + '. </span>').append(link);
            $('#weibo-hot-list').append(listItem);
            count++;
        });
    });
});