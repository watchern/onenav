# 安装须知

* 本主题依赖宿主框架`onenav`程序。

* 本主题依赖 `think-template` 安装时一般无需操作

* 本主题文件夹名称为 **tushan2** 安装时请勿修改文件夹名称，避免资源路径错误

* 将本主题放置于onenav书签程序`/templates/`目录下即可，如果出现缺少依赖，请将终端进入`tushan2`目录,执行`composer install`即可，并且赋予tushan2目录 **775** 以上的权限
