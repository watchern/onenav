<?php
require __DIR__ . '/vendor/autoload.php';
use think\Template;
$template = new Template();
function dump($option = '')
{
    echo "<pre>";
    print_r($option);
    echo "</pre>";
}
$config = [
    'view_path' => __DIR__ . '/view/',
    'view_suffix' => 'html',
    'cache_path'	=>	'./data/'
];

// 获取CID
$cid = empty( $_GET['cid'] ) ? 0 : $_GET['cid'];

$template = new Template($config);
$template->assign(['site' => $site]);

$theme_config = json_decode(json_encode($theme_config),true);
$template->assign(['background' => $theme_config['background']]);
$template->assign(['appName' => $theme_config['AppName']]);
$template->assign(['searchEngine'=>$theme_config['searchEngine']]);
$template->assign(['favicon'=>$theme_config['favicon']]);
$template->assign(['cid' => $cid]);
$template->assign(['link_num' => $link_num]);


foreach ($categorys as $key => $value) {
    $categorys[$key]['links'] = $get_links($value['id']);
}

$template->assign(['categorys' => $categorys]);
$template->assign(['info' => $info]);
// 读取模板文件渲染输出
echo $template->fetch('index');